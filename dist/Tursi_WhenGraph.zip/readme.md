20030615

This is a utility for Fuzzball style Mucks that displays a summary of how many people have been connected over the last week.

An optional color version by Marjan (libAnsi or Glow-style) is also provided.
